(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_bookmark_page_tsx_9fcc2d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_bookmark_page_tsx_9fcc2d._.js",
  "chunks": [
    "static/chunks/node_modules_@radix-ui_react-icons_dist_react-icons_esm_ecd85e.js",
    "static/chunks/node_modules_react-icons_md_index_mjs_78df2b._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_b1b2ef._.js",
    "static/chunks/src_c32606._.js"
  ],
  "source": "dynamic"
});
