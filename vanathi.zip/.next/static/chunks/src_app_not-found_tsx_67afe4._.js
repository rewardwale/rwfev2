(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_not-found_tsx_67afe4._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_not-found_tsx_67afe4._.js",
  "chunks": [
    "static/chunks/_7c6947._.js"
  ],
  "source": "dynamic"
});
