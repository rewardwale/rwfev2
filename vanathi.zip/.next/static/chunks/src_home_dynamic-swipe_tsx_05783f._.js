(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_home_dynamic-swipe_tsx_05783f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_home_dynamic-swipe_tsx_05783f._.js",
  "chunks": [
    "static/chunks/node_modules_swiper_modules_pagination_cb956b.css",
    "static/chunks/src_home_dynamic-swipe_tsx_7575d2._.js"
  ],
  "source": "dynamic"
});
