(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_9fcc2d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_9fcc2d._.js",
  "chunks": [
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_swiper_4fe05b._.js",
    "static/chunks/node_modules_gsap_087228._.js",
    "static/chunks/node_modules_framer-motion_dist_es_d676b8._.js",
    "static/chunks/node_modules_d27d0c._.js",
    "static/chunks/src_ce4f92._.js",
    "static/chunks/_b2428b._.css",
    "static/chunks/src_home_dynamic-swipe_tsx_56f0c1._.js"
  ],
  "source": "dynamic"
});
