(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_reset-password_page_tsx_9fcc2d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_reset-password_page_tsx_9fcc2d._.js",
  "chunks": [
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_react-icons_bs_index_mjs_0b2b17._.js",
    "static/chunks/node_modules_react-icons_md_index_mjs_78df2b._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_e065c0._.js",
    "static/chunks/src_a93691._.js"
  ],
  "source": "dynamic"
});
