(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_home_page_tsx_9fcc2d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_home_page_tsx_9fcc2d._.js",
  "chunks": [
    "static/chunks/src_df3f3c._.js",
    "static/chunks/node_modules_@radix-ui_react-icons_dist_react-icons_esm_ecd85e.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_gsap_087228._.js",
    "static/chunks/node_modules_b0b126._.js"
  ],
  "source": "dynamic"
});
