module.exports = {

"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/favicon--route-entry.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "GET": (()=>GET),
    "dynamic": (()=>dynamic)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/server.js [app-rsc] (ecmascript)");
;
const contentType = "image/x-icon";
const cacheControl = "public, max-age=0, must-revalidate";
const buffer = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAACwAAAArCAYAAAADgWq5AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAhbSURBVHgBxVlfbFtXGf++c+3Yg4o6rxMo12MpCn/U9BG0LDf9w5IHFFuIvaE4QkhMZVqCeACNEq/rxASCtqCqEg8kfoA+8JAUsTVb2vhmnRBvccVY2KrJDkzjMQ5iWmL7nLPfuddOndjXvk467ac29vU9997f+c735/edy3QEzDvriWORY6Na6X6JY82irIVKmO+yPkYqXSbZd1yS3K6QLj/rDrp0BDD1iEWQpGg8pUVkS8ra9nduD7lhr73uFO1apGaTEg4Tz/9w9bFN6hGhCRuifSBaMQfVnaW0e6pMR8DvnPtOjdjGzdxZd6gU9rpQhF8/9+5wleRw5SEQPYjfOMUp8/kjN5kLM74r4ZWn3p4RVnzxzKu9L19YXHaKiQqpGUs8Mv/j1Uc7PieQsHGBz8Xjqf/tPHyrBuEXTjGjiArPu8lC0Ji2hD2yj8QyZ259+Qr1gD+e/mCArP/3I10MVJA5tI4WNTLD9/KP3Qt7jxedYkoQlYJItyV8Z/yf2TPLX8lSCNw4e9+xmKeQxia1JqQ0jXuylhp/kOlgMZaaS0xioaZ2cs+ECLCXYOkqkZt1k6WuhPPjGxmCG4x1cYM/gyizngMpB6RIa5A0TGFSxczKsMWhOdf4HcebktQL51cfX6AuuDhSnFEWLYB0OZDwm+MbU5jZ2thysBWMu3DfsXlFOmVIGmKGlGJDypDWIKuvKkEFJc05K4HjYWIexThbeY/k7PnV5AvUBZee3Jz62RsDubaE8yASjccnn1geygWT3bCtPpEHD9sYDWRzSsucKR5/Ond/HSYcNuS/e3uwratdO/1eFmPmNBuvUeln7zy+RB1wceQ/o0rXOPtm0m38JhpfrHg01YnsrfENOxoTeRjUhjELpOTpb6+cmDZkb2AioDCsPQuIYtA9zq9+MYsROTLuIsUfTDqjDvj53S+sKSFONv/mEYbf4oG61OlircRlnywVdeXDsXRTSdZWdBgkTLQZT+2Y2wVKsllXjOrHw5+jLhBC5S6M/Dvz4HogAiIjy19zgy56BZUO7pkiP5BuHszLzBI+6jvngzVrj11Nm2ZaZqhiPUNd4AedTuwjbAl9stNFwpJlmET75Kh1GRk+rSkUYkwD9CB2EmGu0VoVLsCfPS758XVbKtkxsU8gayBQ1rylNBF/kC8KhZ+5ukMi2NhP0eZfqAp6CUEntfKeK2IcG+7kDg1UWU7rID+HhTWZ7NtdS8GHJ427G9L471JICOH7mrA0Hw9zQRpWlqzH8LVdubZ5b5WDSV9zis/BqgPkRyfMXLtKIYHY8VYjIrm6HfaitF9QSq1n6iS1DuR7HalPC51F7mYv5JgXZvPhuw9k/e3nv/HBgPByxBFwAymx8d34sFLUliyLvryJdq9mYNJSUddK14yaJQssdpOCA1ziDjSFqX4UEnsBdyCt/d55d1iALCxq1weWiOPObBth0w2KLTtCVuuJlfENBys3vxOPl5afun98/LXBm0E3ie3GjlesGjV8AY45kDv73pyxtBbsSK0dMxvoCVNU1oQW08/kHz1UM8BK6Ai0QIvXwUgOQrjsm00uvXLurVPKshLfWm5tOGsRTpAfRX7W8woeZesH5J/gJaHElR/kk2t0BFRFdRsuIVpyoSnB+FMwxLGUWyQiGVhm3ig1I4Cax0qIE3/6dc4I/r2EbASlSQaaJhWrzPUD1/YCUaGEQN4WEINt/dSIcf9Tb0P3mu/lSOyzi0jc+9KaxRFNulFsvWpY1tJKYkPiFFZwDLLzpvZzXkaLvvVr8Gk6BJSIJGQEhAMsjMCgAdbWFg5teE0ZE7CVUvdgwcnFc2/tfyg3CR6me9MIqGn3ROH7twfdqBTTvm+YycB9OLJIhwCI2r9C29Q2S8BqeaxtP5qbbX8w3AJMIgIlWPNMeuWre/2W7xJcn6gv2Jox7YkXLtV922g5GwWkZytzXQCZJLR2d/wfTvPJ07cG13B/BJ0YxUgXD8tokleROxGM+xXWnkt4nRy1rRzIvYUHz8UkheyZsCJV8gh/PagdsgQi3RDVOcNBsMCGB8/iebPNw4yFPetpT+O2rXPYX/OrqTchI77Yph5wYeS/o7rqT7ouL6Mt8vLsqydMnXchcOegIaa9hRZ63mKa2jcvWLgebIFqjbmuyjy9Yw49iRkaiiv2y3/3C41HeLfvo9zfJjZGDw78cOejtJGAyKGLeM4VZO5psNrXh3k+XBfvgbKHraI3qbqmbiivMPgJNhCtpurmXTm2dKq8q2Xy4GDTWYy/9iWkJ3UVT7uC3DKH7y3JX+t6qAVQZpKb9aDzmyhtmthw6FMic/GNz+f2EfYQry7lJ95OtbsIFS5bZZWE5m1pUr2g43oODnAKJa29rGKIY4vAphDIwroK3Ubzb3uEjZUt4q38ePtqZKTl5OtD2XRAkHoWZG7bKe2Q78PwiIZwH7iMqoe9NJs6ANph6tLd5FJbwgZP3hpag2ZxelFpVIWeblg2YLlnTS7W6C72hpnuJL4eIx1YRLIjRVRG1SLwW7z/zPLQgox/ZpJC4mlUNPhEAeW7BPNtwjsK820mvKM5Db9ZwJzusSkkWuXwmW53zxdHiinEmXtwmyoQxsK3J95J0acAs3v50iEqoUd6eeJfXfcNHibM/vDLT7zfccuha5uLLaoMgsZNL4d/D9ErkA0SMaJUVMTy3XbgQ+EvcI+/fvOdKfoE8Oux90/+EpYNO777RkITboI0JOZmuodXXUH47VhxtIpiVSHL/WkP/V1PhA1M11GLxIeZrZOKooWnV8K3PeY9XZVUSpIwxaB0mEa0Z8LNMNusAjuX0sI2turTpj9EuvLehJpun3V0q8bV/hrekCplIUfXto/6JvRjEd7zfqrhKcMAAAAASUVORK5CYII=", 'base64');
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
}
function GET() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"](buffer, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
const dynamic = 'force-static';
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__427628._.js.map