"use client";

import { useState, useEffect } from "react";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { useMediaQuery } from "@/hooks/use-media-query";
import { CommentsContent } from "./commets-content";

interface CommentsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CommentsModal({
  isOpen,
  onClose,
}: CommentsModalProps) {
  const [newComment, setNewComment] = useState("");
  const isMobile = useMediaQuery("(max-width: 768px)");


  useEffect(() => {
    const videoContainer = document.getElementById("video-container");
    if (videoContainer && !isMobile) {
      if (isOpen) {
        videoContainer.style.transform = "translateX(-275px)";
      } else {
        videoContainer.style.transform = "translateX(0)";
      }
    }
  }, [isOpen, isMobile]);

  if (isMobile) {
    return (
      <Sheet open={isOpen} onOpenChange={onClose}>
        <SheetContent side="bottom" className="h-[80vh] rounded-t-xl p-0">
          <CommentsContent
            onClose={onClose}
            newComment={newComment}
            setNewComment={setNewComment}
          />
        </SheetContent>
      </Sheet>
    );
  }

  return (
    isOpen && (
      <div
        style={{
          translate: "150%",
          border:'1px solid #979797',
          borderRadius:'18px'
        }}
        className={`hidden md:block fixed top-4 right-0 w-[450px] h-[calc(88vh-64px)] bg-background border-l transform transition-transform duration-700 ease-in-out


      `}
      >
        <CommentsContent
          // totalComments={totalComments}
          onClose={onClose}
          newComment={newComment}
          setNewComment={setNewComment}
        />
      </div>
    )
  );
}
