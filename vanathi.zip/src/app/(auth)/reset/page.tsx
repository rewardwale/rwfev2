import ResetForm from "@/components/reset/reset-form";

export default function Reset() {
  return (
    <div className="flex justify-center w-full items-center">
      <ResetForm />
    </div>
  );
}
