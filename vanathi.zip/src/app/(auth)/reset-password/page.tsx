"use client";
import NewPasswordForm from "@/components/reset/password-form";

export default function NewPasswordPage() {
  return (
    <div className="flex justify-center w-full items-center">
      <NewPasswordForm />
    </div>
  );
}
