import { apiClient } from "../lib/apiClient";

export async function getAllBookMarks(skip: number) {
  const response = await apiClient(
    `bookmarkList?limit=50&skip=${skip}&latestFirst=true`,
    "GET",
  );
  https: if (response.success && response.data) {
    return response.data;
  } else {
    console.error("Failed to fetch landing page data:", response.error);
    return null;
  }
}

export async function deleteBookMark(videoId: string) {
  const response = await apiClient(`bookmark/${videoId}`, "DELETE");
  console.log(";:::1:::", response);
  if (response.success && response.data) {
    return response.data;
  } else {
    console.error("Failed to fetch landing page data:", response.error);
    return null;
  }
}

export async function addBookMark(videoId: string) {
  const response = await apiClient(`videoBookmark/${videoId}`, "POST");
  console.log(";:::2:::", response);
  if (response.success && response.data) {
    return response.data;
  } else {
    console.error("Failed to fetch landing page data:", response.error);
    return null;
  }
}
