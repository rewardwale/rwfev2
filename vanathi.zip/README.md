node 20.12 and above required
npm 10.8.2 is the package manager

font to used as utility font-Inter, font-Roboto

#TransitionLink
https://www.youtube.com/watch?v=fx6KMItwJAw

#Custom Themes and Mode
https://www.youtube.com/watch?v=dgT9vqTAV48
